const GITHUB_RAW_URL = "https://raw.githubusercontent.com/unrecognized-genius/Anti-MalwareSites/refs/heads/main/blocked_sites/home1.txt";
const REDIRECT_URL = "https://anti-malwaresites.web.app/you_are_protected.html";

async function fetchBlockedDomains() {
    try {
        let response = await fetch(GITHUB_RAW_URL);
        let text = await response.text();
        let domains = text.split("\n").map(line => line.trim()).filter(line => line);

        let rules = domains.map((domain, index) => ({
            "id": index + 1,
            "priority": 1,
            "action": { "type": "redirect", "redirect": { "url": REDIRECT_URL } },
            "condition": { "urlFilter": `||${domain}`, "resourceTypes": ["main_frame"] }
        }));

        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: rules.map(r => r.id),
            addRules: rules
        });

        console.log("🔄 Список блокировок обновлён:", domains);
    } catch (error) {
        console.error("⚠️ Ошибка загрузки списка доменов:", error);
    }
}

fetchBlockedDomains();

setInterval(fetchBlockedDomains, 600000);